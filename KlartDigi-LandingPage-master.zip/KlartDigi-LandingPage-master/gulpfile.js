'use strict';

var gulp = require('gulp');
var sass = require('gulp-sass');
var shelljs = require('shelljs');

/**
 * Load the sample in src/app/index
 */
gulp.task('start', function (done) {
    var browserSync = require('browser-sync');
    var bs = browserSync.create('Klart`Digi');
    var options = {
        server: { baseDir: ['./'] },
        ui: false
    };
    bs.init(options, done);
});

/** 
 * Compile scss to css
 */
gulp.task('styles', function () {
    return gulp.src('styles/*.scss')
        .pipe(sass().on('error', sass.logError))
        .pipe(gulp.dest('./styles/'));
});

/** 
 * publish
 */
gulp.task('publish', function (done) {
    shelljs.mkdir('-p', './dist');
    shelljs.mkdir('-p', './dist/assets');
    shelljs.mkdir('-p', './dist/scripts');
    shelljs.mkdir('-p', './dist/styles');
    shelljs.mkdir('-p', './dist/styles/fonts');
    shelljs.cp('-rf', './assets/*', './dist/assets');
    shelljs.cp('-rf', './scripts/*', './dist/scripts');
    shelljs.cp('-rf', './styles/*.css', './dist/styles');
    shelljs.cp('-rf', './styles/fonts/*', './dist/styles/fonts');
    shelljs.cp('-rf', './index.html', './dist');
    done();
});
